//230202116 İrem Kaynar
#include <stdio.h>
#include <math.h>
#include <curl/curl.h> //url okutma icin
#include <SDL2/SDL.h> //cizim icin

//cizilen seklin alanini hesaplama ve bulunan degeri 10 ile carpip rezerv degerinin hesaplanmasi fonksiyonu
float alanHesapla(SDL_Point* koordinat, int nokta_sayisi) {
    float alan = 0.0;

    for (int i = 0; i < nokta_sayisi - 1; i++) {
        alan += (koordinat[i].x * koordinat[i + 1].y - koordinat[i + 1].x * koordinat[i].y);
    }

    alan += (koordinat[nokta_sayisi - 1].x * koordinat[0].y - koordinat[0].x * koordinat[nokta_sayisi - 1].y);

    return 0.5 * fabs(alan) * 10; /*gauss alan formulu alanin iki katini hesaplar, bu nedenle 0.5 ile carptik
        ve alan sonucu daima pozitif olmali "floating-point absolute value.". 10 ile carpip rezerv degeri bulunur*/
}


int main() {

    //url okutup yazdırma
    CURL *curl;
    CURLcode url_sonucu;

    curl = curl_easy_init();
    if (curl) {
        curl_easy_setopt(curl, CURLOPT_URL, "http://zplusorg.com/prolab.txt");
        url_sonucu = curl_easy_perform(curl);

        if (url_sonucu != CURLE_OK) {
            fprintf(stderr, "curl_easy_perform() failed: %s\n", curl_easy_strerror(url_sonucu));
        }

        curl_easy_cleanup(curl);
    }


    //cizim penceresi acma

    //kontrol
    if (SDL_Init(SDL_INIT_VIDEO) < 0) {
        fprintf(stderr, "SDL baslatılamadı! SDL_Error: %s\n", SDL_GetError());
        return 1;
    }

    //ana pencerenin olusturulması
    SDL_Window* pencere = SDL_CreateWindow("Cokgen cizim ornegi", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, 1200, 700, SDL_WINDOW_SHOWN);
    if (pencere == NULL) {
        fprintf(stderr, "Pencere olusturulamadı! SDL_Error: %s\n", SDL_GetError());
        return 1;
    }

    //rendererin olusturulması
    SDL_Renderer* renderer = SDL_CreateRenderer(pencere, -1, SDL_RENDERER_ACCELERATED);
    if (renderer == NULL) {
        fprintf(stderr, "Renderer olusturulamadı! SDL_Error: %s\n", SDL_GetError());
        return 1;
    }

    //kullanıcıdan çizidrilecek koordinat satırını isteme
    int koordinat_satir_no;
    char koordinat_satir_harf;
    printf("\nLütfen hangi satırdaki koordinat noktalarını çizdirmek istediğinizi giriniz. (Örn. 1B): ");
    scanf("%d%c", &koordinat_satir_no, &koordinat_satir_harf);

    //kullanıcıdan koordinat noktalarını isteme
    int noktalar;
    printf("Lütfen seçtiginiz satırın kaç noktadan oluştuğunu giriniz: ");
    scanf("%d", &noktalar);

    // Dizi
    int koordinatlar[noktalar][2];

    // Koordinatları al
    for (int i = 0; i < noktalar; i++) {
        printf("Lütfen koordinatlarını sırayla giriniz %d. x ve y: ", i + 1);
        scanf("%d %d", &koordinatlar[i][0], &koordinatlar[i][1]);
    }

    // Koordinatları göster
    printf("Girilen koordinatlar:\n");
    for (int i = 0; i < noktalar; i++) {
        printf("(%d, %d)\n", koordinatlar[i][0], koordinatlar[i][1]);
    }


    //kullanıcıdan birim maliyetleri isteme
    int birim_sondaj_maliyet;
    int birim_platform_maliyet;
    printf("Lütfen birim sondaj maliyetinizi 1-10 arası olacak şekilde giriniz: ");
    scanf("%d", &birim_sondaj_maliyet);
    // girilen sondaj değerin geçerli bir input olduğu kontrolü
    if (birim_sondaj_maliyet < 1 || birim_sondaj_maliyet > 10) {
        printf("Geçersiz sayı girişi. Lütfen 1-10 arası bir sayı giriniz.\n");
        return 1; //error
    }

    printf("Lütfen birim platform maliyetinizi 1-10 arası olacak şekilde giriniz: ");
    scanf("%d", &birim_platform_maliyet);
    // girilen platform değerin geçerli bir input olduğu kontrolü
    if (birim_platform_maliyet < 1 || birim_platform_maliyet > 10) {
        printf("Geçersiz giriş. Lütfen 1-10 arası bir sayı giriniz.\n");
        return 1; // error
    }


    // cizim rengini ayarlama (r: kirmizi, g: yesil, b: mavi, a: alfa(rengin seffafligi))
    SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255);


    float olcekleme = 13.0;

    // cizilecek koordinatlar

    int i; // dizi indeksleri
    int SDL_nokta_sayisi = noktalar;
    SDL_Point SDL_koordinat[SDL_nokta_sayisi];

    //koordinatları SDL formatında yazdırma
    for (i = 0; i < SDL_nokta_sayisi; i++) {
        SDL_koordinat[i].x = koordinatlar[i][0];
        SDL_koordinat[i].y = koordinatlar[i][1];
    }


    //ilk iki nokta arasi cizim
    SDL_RenderDrawLine(renderer, SDL_koordinat[0].x * olcekleme, SDL_koordinat[0].y * olcekleme, SDL_koordinat[1].x * olcekleme, SDL_koordinat[1].y * olcekleme);

    for (i = 1; i < SDL_nokta_sayisi - 1; i++) {
        // 1. indeksten itibaren guncel koordinat 0. indeksteki koordinat ile ayni mi kontrol et
        if (SDL_koordinat[i].x == SDL_koordinat[0].x && SDL_koordinat[i].y == SDL_koordinat[0].y) {
            // eger ayniysa bir adim geç
            continue;
        }

        // ayni degilse cizime devam et
        SDL_RenderDrawLine(renderer, SDL_koordinat[i].x * olcekleme, SDL_koordinat[i].y * olcekleme, SDL_koordinat[i + 1].x * olcekleme, SDL_koordinat[i + 1].y * olcekleme);
    }



    //rezerv degeri hesaplama
    float alan2 = alanHesapla(SDL_koordinat, SDL_nokta_sayisi);
    printf("Rezerv degeri: %f\n", alan2);


    //pencereyi acik tutma
    SDL_RenderPresent(renderer);

    SDL_Event event;
    int cikis = 0;
    while (!cikis) {
        while (SDL_PollEvent(&event) != 0) {
            if (event.type == SDL_QUIT) {
                cikis = 1;
            }
        }
    }



    return 0;
}














